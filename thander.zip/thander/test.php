
<!DOCTYPE html>
<html>
<head>
    <title>Device Photo Preview</title>
</head>
<body>
    <form action="image_upload.php" method="POST" enctype="multipart/form-data">
        <input type="file" name="photo" id="photoInput" accept="image/*">
        <br>
        <img src="#" id="photoPreview" alt="Preview" style="max-width: 300px; display: none;">
        <br>
        <input type="submit" value="Upload">
    </form>

    <script>
        document.getElementById("photoInput").addEventListener("change", function () {
            var preview = document.getElementById("photoPreview");
            var file = this.files[0];
            
            if (file) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    preview.src = e.target.result;
                    preview.style.display = "block";
                };
                reader.readAsDataURL(file);
            } else {
                preview.style.display = "none";
            }
        });
    </script>
</body>
</html>
