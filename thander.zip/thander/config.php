
<?php
$db_host = 'localhost';
$db_name = 'thandar';
$db_user = 'root';
$db_pass = '';
  

try {
    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name", $db_user, $db_pass);
    // ... rest of your database code ...
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>
	