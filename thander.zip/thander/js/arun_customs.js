
// Follow Unfollow Button
 function changeButtonText() {
            var button = document.getElementById("myButton");

            if (button.innerHTML === "Unfollow") {
                button.innerHTML = "Follow";
            } else {
                button.innerHTML = "Unfollow";
            }
        }


//popup profile information
 