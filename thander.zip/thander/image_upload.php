
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["photo"])) {
    $uploadsDirectory = "uploads/"; // Specify the directory where you want to store uploaded photos
    $uploadedFile = $_FILES["photo"];

    // Check for errors during the upload process
    if ($uploadedFile["error"] === UPLOAD_ERR_OK) {
        // Generate a unique filename
        $uniqueFilename = uniqid() . "_" . $uploadedFile["name"];
        $destinationPath = $uploadsDirectory . $uniqueFilename;

        // Move the uploaded file to the destination directory
        if (move_uploaded_file($uploadedFile["tmp_name"], $destinationPath)) {
            echo "Upload successful!";
        } else {
            echo "Error moving file.";
        }
    } else {
        echo "Upload failed with error code: " . $uploadedFile["error"];
    }
}
?>
